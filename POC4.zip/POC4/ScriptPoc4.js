
async function fetchData() {
  try {
    
    const response = await fetch('https://cat-fact.herokuapp.com/facts');
    
    if (!response.ok) {
      throw new Error('Erro ao buscar dados: ' + response.status);
    }

   
    const data = await response.json();

   
    let resultDiv = document.getElementById('result');
    resultDiv.innerHTML = ''; 

    data.slice(0, 5).forEach(post => {
      resultDiv.innerHTML += `
        <div class="post">
          <h2>${post.title}</h2>
          <p>${post.body}</p>
        </div>
        <hr>
      `;
    });

  } catch (error) {
   
    console.error('Erro:', error);
    document.getElementById('result').innerHTML = '<p>Erro ao buscar dados da API.</p>';
  }
}


document.getElementById('fetchButton').addEventListener('click', fetchData);
